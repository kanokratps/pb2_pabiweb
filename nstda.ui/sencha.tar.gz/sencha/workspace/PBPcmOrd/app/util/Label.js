Ext.define('PBPcmOrd.Label', {
    singleton: true,
    a:'test'
});