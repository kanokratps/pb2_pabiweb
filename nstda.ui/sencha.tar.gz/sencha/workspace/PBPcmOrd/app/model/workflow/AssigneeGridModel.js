Ext.define('PBPcmOrd.model.workflow.AssigneeGridModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'assignee'}
    		 , {name : 'user'}
    		 , {name : 'group'}
    		 , {name : 'color'}
    ]
});