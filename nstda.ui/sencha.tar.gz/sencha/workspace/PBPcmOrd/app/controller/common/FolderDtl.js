Ext.define('PBPcmOrd.controller.common.FolderDtl', {
    extend: 'PB.controller.common.FolderDtl'
});