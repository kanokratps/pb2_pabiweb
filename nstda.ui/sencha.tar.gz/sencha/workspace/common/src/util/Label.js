Ext.define('PB.Label', {
    singleton: true
});