Ext.define('PB.model.common.CostControlModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'name'}
    		 , {name : 'action'}
    ]
});