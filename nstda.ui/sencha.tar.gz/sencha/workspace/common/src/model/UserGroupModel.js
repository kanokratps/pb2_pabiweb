Ext.define('PB.model.common.UserGroupModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'name'}
    		 , {name : 'type'}
    		 , {name : 'action'}
    ]
});