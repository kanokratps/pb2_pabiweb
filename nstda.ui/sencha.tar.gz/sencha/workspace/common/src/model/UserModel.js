Ext.define('PB.model.common.UserModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'emp_id'}
    		 , {name : 'title'}
    		 , {name : 'first_name'}
    		 , {name : 'last_name'}
    		 , {name : 'org_name'}
    		 , {name : 'org_desc'}
    		 , {name : 'div_name'}
    		 , {name : 'section_code'}
    		 , {name : 'section_name'}
    		 , {name : 'section_desc'}
    		 , {name : 'pos_name'}
    		 , {name : 'org_id'}
    		 , {name : 'section_id'}
    		 , {name : 'work_phone'}
    		 , {name : 'mobile_phone'}
    		 , {name : 'action'}
    ]
});