Ext.define('PB.model.common.ComboBoxModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'code'}
    		 , {name : 'name'}
    		 , {name : 'select'}
    		 , {name : 'flag2'}
    		 , {name : 'data'}
    ]
});