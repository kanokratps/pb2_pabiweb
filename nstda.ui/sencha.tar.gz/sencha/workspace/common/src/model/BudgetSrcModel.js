Ext.define('PB.model.common.BudgetSrcModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'type'}
    		 , {name : 'name'}
    		 , {name : 'cc'}
    		 , {name : 'org'}
    		 , {name : 'action'}
    ]
});