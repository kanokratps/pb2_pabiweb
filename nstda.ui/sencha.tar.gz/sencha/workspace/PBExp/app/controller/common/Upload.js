Ext.define('PBExp.controller.common.Upload', {
    extend: 'PB.controller.common.Upload'
});