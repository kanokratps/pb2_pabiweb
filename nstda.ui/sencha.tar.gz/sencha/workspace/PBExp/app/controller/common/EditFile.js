Ext.define('PBExp.controller.common.EditFile', {
    extend: 'PB.controller.common.EditFile'
});