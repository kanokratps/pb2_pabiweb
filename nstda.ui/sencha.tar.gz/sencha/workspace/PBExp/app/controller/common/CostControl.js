Ext.define('PBExp.controller.common.CostControl', {
    extend: 'PB.controller.common.CostControl'
});