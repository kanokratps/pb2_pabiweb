Ext.define('PBExp.controller.common.OtherUser', {
    extend: 'PB.controller.common.OtherUser'
});