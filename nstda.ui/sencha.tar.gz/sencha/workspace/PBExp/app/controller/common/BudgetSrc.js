Ext.define('PBExp.controller.common.BudgetSrc', {
    extend: 'PB.controller.common.BudgetSrc'
});