Ext.define('PBExp.controller.common.EmployeeUser', {
    extend: 'PB.controller.common.EmployeeUser'
});