Ext.define('PBExp.controller.common.FolderDtl', {
    extend: 'PB.controller.common.FolderDtl'
});