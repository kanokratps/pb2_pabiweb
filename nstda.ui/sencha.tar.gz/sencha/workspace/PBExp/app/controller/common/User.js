Ext.define('PBExp.controller.common.User', {
    extend: 'PB.controller.common.User'
});