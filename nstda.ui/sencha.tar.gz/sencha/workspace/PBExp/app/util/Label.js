Ext.define('PBExp.Label', {
    singleton: true,
    a:'test'
});