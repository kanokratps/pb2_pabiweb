Ext.define('PBExp.model.OldGridModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'ord'}
    		 , {name : 'number'}
    		 , {name : 'name'}
    		 , {name : 'waitamt'}
    		 , {name : 'balance'}
    		 , {name : 'action'}
    ]
});