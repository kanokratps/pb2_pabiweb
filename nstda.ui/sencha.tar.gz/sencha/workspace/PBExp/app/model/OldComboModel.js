Ext.define('PBExp.model.OldComboModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
    		 , {name : 'objective_type_name'}
    		 , {name : 'objective'}
    		 , {name : 'total_cnv'}
    		 , {name : 'action'}
    ]
});