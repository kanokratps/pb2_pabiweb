Ext.define('PBAdmin.model.main.GroupModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
			 , {name : 'code'}
    		 , {name : 'name'}
    		 , {name : 'type'}
    		 , {name : 'rewarning'}
    		 , {name : 'action'}
    ]
});