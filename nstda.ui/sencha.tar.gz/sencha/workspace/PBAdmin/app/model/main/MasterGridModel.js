Ext.define('PBAdmin.model.main.MasterGridModel', {
    extend: 'Ext.data.Model',
    fields : [ {name : 'id'}
			 , {name : 'code'}
			 , {name : 'type'}
    		 , {name : 'name'}
    		 , {name : 'flag1'}
    		 , {name : 'flag2'}
    		 , {name : 'flag3'}
    		 , {name : 'flag4'}
    		 , {name : 'flag5'}
    		 , {name : 'is_active'}
    		 , {name : 'is_system'}
    		 , {name : 'action'}
    ]
});