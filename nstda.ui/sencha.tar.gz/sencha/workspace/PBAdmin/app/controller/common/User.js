Ext.define('PBAdmin.controller.common.User', {
    extend: 'PB.controller.common.User'
});