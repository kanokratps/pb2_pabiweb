Ext.define('Ext.overrides.grid.column.Action', {
    override: 'Ext.grid.column.Action',

    constructor: function () {
        this.callParent(arguments);
        Ext.each(this.items, function () {
            var handler;
            if (this.action) {
                handler = this.handler; // save configured handler
                this.handler = function (view, rowIdx, colIdx, item, e, record) {
                    view.up('grid').fireEvent(item.action, record);
                    handler && handler.apply(this, arguments);
                };
            }
        });
    }

});