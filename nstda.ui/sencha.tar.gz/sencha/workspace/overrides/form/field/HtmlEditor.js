Ext.define('Ext.overrides.form.field.HtmlEditor', {
    override: 'Ext.form.field.HtmlEditor',

	getSelectedText: function(clip){
	    var doc = this.getDoc(), selDocFrag;
	    var txt = '', hasHTML = false, selNodes = [], ret, html = '';
	    if (this.win.getSelection || doc.getSelection) {
	        // FF, Chrome, Safari
	        var sel = this.win.getSelection();
	        if (!sel) {
	            sel = doc.getSelection();
	        }
	        if (clip) {
	            selDocFrag = sel.getRangeAt(0).extractContents();
	        } else {
	            selDocFrag = this.win.getSelection().getRangeAt(0).cloneContents();
	        }
	        Ext.each(selDocFrag.childNodes, function(n){
	            if (n.nodeType !== 3) {
	                hasHTML = true;
	            }
	        });
	        if (hasHTML) {
	            var div = document.createElement('div');
	            div.appendChild(selDocFrag);
	            html = div.innerHTML;
	            txt = this.win.getSelection() + '';
	        } else {
	            html = txt = selDocFrag.textContent;
	        }
	        ret = {
	            textContent: txt,
	            hasHTML: hasHTML,
	            html: html
	        };
	    } else if (doc.selection) {
	        // IE
	        this.win.focus();
	        txt = doc.selection.createRange();
	        if (txt.text !== txt.htmlText) {
	            hasHTML = true;
	        }
	        ret = {
	            textContent: txt.text,
	            hasHTML: hasHTML,
	            html: txt.htmlText
	        };
	    } else {
	        return {
	            textContent: ''
	        };
	    }
	    
	    return ret;
	}

});