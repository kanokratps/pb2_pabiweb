Ext.define('PBHrSal.Label', {
    singleton: true,
    a:'test'
});