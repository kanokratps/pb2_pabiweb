Ext.define('PBHrSal.controller.common.FolderDtl', {
    extend: 'PB.controller.common.FolderDtl'
});