Ext.define('PBPcm.Label', {
    singleton: true,
    a:'test'
});