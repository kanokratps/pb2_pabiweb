Ext.define('PBPcm.controller.item.Main', {
    extend: 'Ext.app.Controller',
    
	refs:[{
	    ref: 'main',
	    selector:'pcmReqMain'
    }],
	
	init:function() {
	}
	
});
