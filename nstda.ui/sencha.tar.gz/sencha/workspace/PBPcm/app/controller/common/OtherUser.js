Ext.define('PBPcm.controller.common.OtherUser', {
    extend: 'PB.controller.common.OtherUser'
});