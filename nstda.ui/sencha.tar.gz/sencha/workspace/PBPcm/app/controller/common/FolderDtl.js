Ext.define('PBPcm.controller.common.FolderDtl', {
    extend: 'PB.controller.common.FolderDtl'
});