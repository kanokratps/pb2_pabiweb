Ext.define('PBPcm.controller.common.User', {
    extend: 'PB.controller.common.User'
});