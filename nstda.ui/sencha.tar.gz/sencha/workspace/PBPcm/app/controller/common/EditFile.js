Ext.define('PBPcm.controller.common.EditFile', {
    extend: 'PB.controller.common.EditFile'
});