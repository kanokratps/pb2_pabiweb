Ext.define('PBPcm.controller.common.Upload', {
    extend: 'PB.controller.common.Upload'
});