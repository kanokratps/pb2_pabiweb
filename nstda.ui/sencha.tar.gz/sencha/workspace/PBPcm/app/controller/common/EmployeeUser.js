Ext.define('PBPcm.controller.common.EmployeeUser', {
    extend: 'PB.controller.common.EmployeeUser'
});