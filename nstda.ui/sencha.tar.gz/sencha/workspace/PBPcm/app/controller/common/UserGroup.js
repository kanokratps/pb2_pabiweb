Ext.define('PBPcm.controller.common.UserGroup', {
    extend: 'PB.controller.common.UserGroup'
});