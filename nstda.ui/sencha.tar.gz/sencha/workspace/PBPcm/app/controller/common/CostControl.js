Ext.define('PBPcm.controller.common.CostControl', {
    extend: 'PB.controller.common.CostControl'
});